<!DOCTYPE html>
<html>
<head>
    <title>Registrar usuario</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <h1>Registro</h1>
    <form method="post" action="">
        <h2>Crear cuenta</h2>
        <input type="text" id="username" name="username" placeholder="Nombre de usuario" required>
        <input type="text" id="name" name="name" placeholder="Nombre completo" required>
        <input type="email" id="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" id="password" name="password" placeholder="Contraseña" required>
        <input type="submit" name="register" value="Registrarse">
    </form>
    
    <h2>Iniciar sesión</h2>
    <form method="post" action="">
        <input type="text" name="username" placeholder="Nombre de usuario">
        <input type="password" name="password" placeholder="Contraseña">
        <input type="submit" name="login" value="Iniciar sesión">
    </form>
    
    <?php 
    include("con_db.php");
    
    if (isset($_POST['register'])) {
        // Verificar que se hayan proporcionado todos los campos
        if(strlen($_POST['username']) >= 1 && strlen($_POST['name']) >= 1 && strlen($_POST['password']) >= 1 && strlen($_POST['email']) >= 1) {
            $username = trim($_POST['username']);
            $name = trim($_POST['name']);
            $password = trim($_POST['password']);
            $email = trim($_POST['email']);

            // Utilizar NOW() para obtener la fecha y hora actuales
            $fecha_creacion = "NOW()";

            // Verificar si el nombre de usuario ya existe antes de insertar
            $consulta_existencia = "SELECT * FROM usuarios WHERE nombre_usuario = '$username'";
            $resultado_existencia = mysqli_query($conex, $consulta_existencia);

            if (mysqli_num_rows($resultado_existencia) == 0) {
                // El nombre de usuario no existe, se puede insertar
                $consulta = "INSERT INTO usuarios(nombre_usuario, nombre, contraseña, email, fecha_creacion) VALUES ('$username', '$name', '$password', '$email', $fecha_creacion)";
                $resultado = mysqli_query($conex, $consulta);

                if ($resultado) {
                    ?>
                    <h3 class="ok">¡Te has inscripto correctamente!</h3>
                    <?php
                } else {
                    ?>
                    <h3 class="bad">¡Ups ha ocurrido un error!</h3>
                    <?php
                }
            } else {
                ?>
                <h3 class="bad">¡El nombre de usuario ya existe!</h3>
                <?php
            }
        } else {
            ?>
            <h3 class="bad">¡Por favor complete todos los campos!</h3>
            <?php
        }
    }

    session_start();

    if(isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $consulta = "SELECT * FROM usuarios WHERE nombre_usuario='$username' AND contraseña='$password'";
        $resultado = mysqli_query($conex, $consulta);

        if(mysqli_num_rows($resultado) > 0) {
            // El usuario existe, iniciar sesión
            $_SESSION['username'] = $username;
            header("Location: menu.php"); // Redireccionar al usuario a una página de bienvenida
            exit();
        } else {
            echo "Nombre de usuario o contraseña incorrectos";
        }
    }
    ?>
</body>
</html>

