<?php
// Verificar si se envió el ID del vendedor a eliminar
if(isset($_GET['id'])) {
    // Obtener el ID del vendedor
    $id_vendedor = $_GET['id'];

    // Conectar a la base de datos
    include("con_db.php");

    // Preparar la consulta SQL para eliminar la cuenta del vendedor
    $consulta = "DELETE FROM vendedores WHERE ID_Vendedor = $id_vendedor";

    // Ejecutar la consulta
    if(mysqli_query($conex, $consulta)) {
        echo "La cuenta de vendedor se ha eliminado exitosamente.";
    } else {
        echo "Error al eliminar la cuenta de vendedor: " . mysqli_error($conex);
    }

    // Cerrar la conexión
    mysqli_close($conex);
}
?>
