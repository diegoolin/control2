<?php
session_start(); // Iniciar la sesión si no se ha iniciado
// Verificar si el vendedor ha iniciado sesión
if(!isset($_SESSION['id_vendedor'])) {
    // Si el vendedor no ha iniciado sesión, redirigirlo al inicio de sesión
    header("Location: login_vendedor.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Página del Vendedor</title>
</head>
<body>
    <?php
    // Incluir el archivo de conexión a la base de datos
    include("con_db.php");

    // Obtener el ID del vendedor autenticado desde la sesión
    $id_vendedor = $_SESSION['id_vendedor'];
    
    // Consulta SQL para obtener el nombre del vendedor basado en su ID
    $query_nombre_vendedor = "SELECT Nombre FROM vendedores WHERE ID_Vendedor = '$id_vendedor'";
    $resultado_nombre_vendedor = mysqli_query($conex, $query_nombre_vendedor);
    
    // Verificar si se encontró el nombre del vendedor
    if ($fila = mysqli_fetch_assoc($resultado_nombre_vendedor)) {
        $nombre_vendedor = $fila['Nombre'];
        echo "<h1>Bienvenido $nombre_vendedor</h1>";
    } else {
        echo "<h1>Bienvenido Vendedor</h1>";
    }
    ?>

    <h2>Ingresar Nuevo Libro</h2>
    <form method="post" action="guardar_libro.php">
    <form method="post" action="guardar_libro.php">
        <label for="identificador">Identificador único:</label><br>
        <input type="text" id="identificador" name="identificador" required><br><br>
        
        <label for="titulo">Título:</label><br>
        <input type="text" id="titulo" name="titulo" required><br><br>
        
        <label for="descripcion">Descripción:</label><br>
        <textarea id="descripcion" name="descripcion" rows="4" cols="50"></textarea><br><br>
        
        <label for="fecha_alta">Fecha de Alta:</label><br>
        <input type="date" id="fecha_alta" name="fecha_alta" required><br><br>
        
        <label for="genero">Género:</label><br>
        <input type="text" id="genero" name="genero" required><br><br>
        
        <label for="precio">Precio:</label><br>
        <input type="number" id="precio" name="precio" min="0" step="0.01" required><br><br>
        
        <label for="formato">Formato:</label><br>
        <input type="text" id="formato" name="formato" required><br><br>
        
        <label for="autor">Autor:</label><br>
        <input type="text" id="autor" name="autor" required><br><br>
        
        <label for="idioma">Idioma:</label><br>
        <input type="text" id="idioma" name="idioma" required><br><br>
        
        <label for="disponibilidad">Disponibilidad:</label><br>
        <select id="disponibilidad" name="disponibilidad" required>
            <option value="Disponible">Disponible</option>
            <option value="Agotado">Agotado</option>
        </select><br><br>
        
        <input type="submit" value="Guardar">
    </form>
</body>
</html>
