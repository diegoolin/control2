<?php
include("con_db.php");

if(isset($_GET['id_vendedor'])) {
    $id_vendedor = $_GET['id_vendedor'];

    $consulta = "SELECT * FROM vendedores WHERE ID_Vendedor='$id_vendedor'";
    $resultado = mysqli_query($conex, $consulta);
    $vendedor = mysqli_fetch_assoc($resultado);
} else {
    header("Location: seleccionar_vendedor.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar cuenta de vendedor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Modificar cuenta de vendedor</h1>
    <form method="post" action="procesar_modificacion.php">
        <input type="hidden" name="id_vendedor" value="<?php echo $vendedor['ID_Vendedor']; ?>">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" value="<?php echo $vendedor['Nombre']; ?>" required><br>
        <label for="correo">Correo electrónico:</label><br>
        <input type="email" id="correo" name="correo" value="<?php echo $vendedor['Email']; ?>" required><br>
        <label for="contraseña">Contraseña:</label><br>
        <input type="text" id="contraseña" name="contraseña" value="<?php echo $vendedor['Contraseña']; ?>" required><br>
        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" value="<?php echo $vendedor['Telefono']; ?>"><br><br>
        <input type="submit" name="submit" value="Guardar cambios">
    </form>
</body>
</html>