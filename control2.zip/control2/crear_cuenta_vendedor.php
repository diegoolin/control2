<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="css/estilo.css">
    <title>Crear Cuenta de Vendedor</title>
</head>
<body>
    <h1>Crear Cuenta de Vendedor</h1>
    
    <!-- Formulario para crear la cuenta del vendedor -->
    <form method="post" action="">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br><br>
        
        <label for="email">Correo electrónico:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" required><br><br>
        
        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        
        <input type="submit" value="Crear Cuenta">
    </form>

    <?php
    // Incluir archivo de conexión a la base de datos
    include("con_db.php");

    // Verificar si se enviaron los datos del formulario
    if(isset($_POST['nombre'], $_POST['email'], $_POST['telefono'], $_POST['contraseña'])) {
        // Obtener los datos del formulario
        $nombre = $_POST['nombre'];
        $email = $_POST['email'];
        $telefono = $_POST['telefono'];
        $contraseña = $_POST['contraseña'];

        // Insertar la cuenta del vendedor en la base de datos
        $consulta = "INSERT INTO vendedores (Nombre, Email, Telefono, Contraseña, Fecha_Alta) VALUES ('$nombre', '$email', '$telefono', '$contraseña', CURRENT_DATE())";
        $resultado = mysqli_query($conex, $consulta);

        if($resultado) {
            echo "Cuenta de vendedor creada exitosamente.";
        } else {
            echo "Error al crear la cuenta de vendedor. Intente de nuevo.";
        }
    }
    ?>
</body>
</html>
